require 'spec_helper'

describe 'movies' do
	@movie = Movie.new
	all_ratings = Movie.all_ratings
	similar_movies = @movie.directors


end